from django.contrib import admin
from .models import Note
from .models import Writer

# Register your models here.
# Note model
admin.site.register(Note)
# Writer model
admin.site.register(Writer)