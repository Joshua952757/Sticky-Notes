from django.shortcuts import render, redirect, get_object_or_404
from .models import Note
from .forms import NoteForm, WriterForm


def note_list(request):
    note = Note.objects.all().order_by('-updated_at')
    return render(request, 'notes_list.html', {'notes': note})


def note_detail(request, pk):
    note = get_object_or_404(Note, pk=pk)
    return render(request, 'notes_details.html', {'note': note})


def note_create(request):
    if request.method == 'POST':
        form = NoteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('note_list')
    else:
        form = NoteForm()
    return render(request, 'notes_forms.html', {'form': form, 'action': 'Create'})


def note_update(request, pk):
    note = get_object_or_404(Note, pk=pk)
    if request.method == 'POST':
        form = NoteForm(request.POST, instance=note)
        if form.is_valid():
            form.save()
            return redirect('note_list')
    else:
        form = NoteForm(instance=note)
    return render(request, 'notes_forms.html', {'form': form, 'action': 'Update'})


def note_delete(request, pk):
    note = get_object_or_404(Note, pk=pk)
    if request.method == 'POST':
        note.delete()
        return redirect('note_list')
    return render(request, 'notes_confirm_delete.html', {'note': note})


def writer_create(request):
    if request.method == 'POST':
        form = WriterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('note_list')
    else:
        form = WriterForm()
    return render(request, 'writers_forms.html', {'form': form, 'action': 'Create'})