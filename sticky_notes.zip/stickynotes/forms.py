from django import forms
from .models import Note, Writer


class NoteForm(forms.ModelForm):
    class Meta:
        model = Note
        fields = ['title', 'content', 'writer']

      
class WriterForm(forms.ModelForm):
    class Meta:
        model = Writer
        fields = ['name']