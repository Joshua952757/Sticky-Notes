from django.test import TestCase
from django.urls import reverse
from .models import Note, Writer
from datetime import datetime


class NoteModelTest(TestCase):
    def setUp(self):
        # Create an Writer object
        writer = Writer.objects.create(name='Test Writer')
        # Create a Note object for testing
        Note.objects.create(title='Test Note',
                            content='This is a test note.',
                            created_at=datetime.now(),
                            updated_at=datetime.now(),
                            writer=writer)

    def test_note_has_title(self):
 # Test that a Post object has the expected title
        note = Note.objects.get(id=1)
        self.assertEqual(note.title, 'Test Note')

    def test_note_has_content(self):
 # Test that a Post object has the expected content
        note = Note.objects.get(id=1)
        self.assertEqual(note.content, 'This is a test note.')


class NoteViewTest(TestCase):
    def setUp(self):
 # Create an Writer object
        writer = Writer.objects.create(name='Test Writer')
 # Create a Note object for testing views'Test Note content=
        Note.objects.create(title='Test Note',
                            content='This is a test note.',
                            created_at=datetime.now(),
                            updated_at=datetime.now(),
                            writer=writer)

    def test_notes_lists_view(self):
 # Test the post-list view
        response = self.client.get(reverse('note_list'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')

    def test_notes_details_view(self):
       # Test the post-detail view
        note = Note.objects.get(id=1)
        response = self.client.get(reverse('note_detail', args=[str(note.id)]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')
        self.assertContains(response, 'This is a test note.')
